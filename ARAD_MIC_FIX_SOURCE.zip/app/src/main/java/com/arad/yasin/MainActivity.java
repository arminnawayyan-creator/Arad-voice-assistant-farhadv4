package com.arad.yasin;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient.FileChooserParams;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<android.net.Uri[]> fileCallback;
    private static final int FILE_PICKER = 4107;
    private static final int AUDIO_PERMISSION = 4108;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private boolean listeningRequested = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(12, 17, 21));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(12, 17, 21));
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("fa", "IR"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(12, 17, 21));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new AradVoiceBridge(), "AradVoice");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(android.webkit.PermissionRequest request) {
                // Web speech API fallback only: grant audio capture only after Android runtime permission is granted.
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    for (String resource : request.getResources()) {
                        if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                            request.grant(new String[]{resource});
                            return;
                        }
                    }
                }
                request.deny();
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<android.net.Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/csv", "text/plain", "application/vnd.ms-excel", "application/json"});
                startActivityForResult(Intent.createChooser(intent, "انتخاب فایل داده"), FILE_PICKER);
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void sendToPage(String function, String value) {
        if (webView == null) return;
        String safe = org.json.JSONObject.quote(value == null ? "" : value);
        runOnUiThread(() -> webView.evaluateJavascript(function + "(" + safe + ")", null));
    }

    private void startNativeListening() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            listeningRequested = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION);
            return;
        }
        beginRecognition();
    }

    private void beginRecognition() {
        listeningRequested = false;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendToPage("window.onAradVoiceError", "recognizer-unavailable");
            return;
        }
        try {
            if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { sendToPage("window.onAradVoiceStatus", "listening"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { sendToPage("window.onAradVoiceStatus", "processing"); }
                @Override public void onError(int error) {
                    String message;
                    switch (error) {
                        case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: message = "permission-denied"; break;
                        case SpeechRecognizer.ERROR_NETWORK: case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: message = "network-error"; break;
                        case SpeechRecognizer.ERROR_NO_MATCH: message = "no-match"; break;
                        case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: message = "busy"; break;
                        case SpeechRecognizer.ERROR_AUDIO: message = "audio-error"; break;
                        default: message = "recognition-error-" + error;
                    }
                    sendToPage("window.onAradVoiceError", message);
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    sendToPage("window.onAradVoiceResult", matches != null && !matches.isEmpty() ? matches.get(0) : "");
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR");
            intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            sendToPage("window.onAradVoiceError", "start-failed");
        }
    }

    private class AradVoiceBridge {
        @JavascriptInterface public boolean isTtsReady() { return ttsReady; }
        @JavascriptInterface public void startListening() { runOnUiThread(() -> startNativeListening()); }
        @JavascriptInterface public void stopListening() { runOnUiThread(() -> { listeningRequested = false; if (speechRecognizer != null) speechRecognizer.cancel(); sendToPage("window.onAradVoiceStatus", "stopped"); }); }
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> {
                if (tts != null && ttsReady && text != null && !text.isEmpty()) {
                    if (Build.VERSION.SDK_INT >= 21) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "arad-utterance");
                    else tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                }
            });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginRecognition();
            else { listeningRequested = false; sendToPage("window.onAradVoiceError", "permission-denied"); }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            android.net.Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new android.net.Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        if (webView != null) { webView.removeJavascriptInterface("AradVoice"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
